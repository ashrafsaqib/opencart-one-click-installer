<?php
// HTTP
define('HTTP_SERVER', 'http://dev.local/oc23f/admin/');
define('HTTP_CATALOG', 'http://dev.local/oc23f/');

// HTTPS
define('HTTPS_SERVER', 'http://dev.local/oc23f/admin/');
define('HTTPS_CATALOG', 'http://dev.local/oc23f/');

// DIR
define('DIR_APPLICATION', '/Users/saqibashraf/Desktop/oc/oc23f/admin/');
define('DIR_SYSTEM', '/Users/saqibashraf/Desktop/oc/oc23f/system/');
define('DIR_IMAGE', '/Users/saqibashraf/Desktop/oc/oc23f/image/');
define('DIR_LANGUAGE', '/Users/saqibashraf/Desktop/oc/oc23f/admin/language/');
define('DIR_TEMPLATE', '/Users/saqibashraf/Desktop/oc/oc23f/admin/view/template/');
define('DIR_CONFIG', '/Users/saqibashraf/Desktop/oc/oc23f/system/config/');
define('DIR_CACHE', '/Users/saqibashraf/Desktop/oc/oc23f/system/storage/cache/');
define('DIR_DOWNLOAD', '/Users/saqibashraf/Desktop/oc/oc23f/system/storage/download/');
define('DIR_LOGS', '/Users/saqibashraf/Desktop/oc/oc23f/system/storage/logs/');
define('DIR_MODIFICATION', '/Users/saqibashraf/Desktop/oc/oc23f/system/storage/modification/');
define('DIR_UPLOAD', '/Users/saqibashraf/Desktop/oc/oc23f/system/storage/upload/');
define('DIR_CATALOG', '/Users/saqibashraf/Desktop/oc/oc23f/catalog/');

// DB
define('DB_DRIVER', 'mysqli');
define('DB_HOSTNAME', 'localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', 'yourpassword');
define('DB_DATABASE', 'oc23f');
define('DB_PORT', '3306');
define('DB_PREFIX', 'oc_');
